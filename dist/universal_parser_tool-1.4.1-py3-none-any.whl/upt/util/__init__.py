import os

CONFIG_PATH = os.path.expanduser("~/.uptrc")